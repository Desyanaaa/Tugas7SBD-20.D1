<?php
$koneksi = mysqli_connect('localhost','root','','klinik_312010096');

if (mysqli_connect_errno()){

	echo "Koneksi database gagal : " . mysqli_connect_error();

}

?>
